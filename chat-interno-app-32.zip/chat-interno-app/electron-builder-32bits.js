// Configuração da versão 32 bits: igual à normal, mas com outro nome de
// instalador e um canal de atualização próprio ("latest-32bits.yml"),
// pra o app 32 bits nunca baixar a atualização de 64 bits (e vice-versa).
const base = require('./package.json').build;
module.exports = {
  ...base,
  win: { ...base.win, target: [{ target: 'nsis', arch: ['ia32'] }], artifactName: 'Chat-Interno-Setup-${version}-32bits.${ext}' },
  publish: base.publish.map(p => ({ ...p, channel: 'latest-32bits' }))
};
