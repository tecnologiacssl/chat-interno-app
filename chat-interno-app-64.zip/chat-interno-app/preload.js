// Ponte segura entre a página do portal e o app (sem dar acesso ao Node).
// O index.html só usa "window.csslDesktop" se ele existir — no navegador
// comum ele não existe e nada muda.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('csslDesktop', {
  app: 'chat-interno',
  naoLidas: (total) => ipcRenderer.send('chat:nao-lidas', total),
  novaMensagem: () => ipcRenderer.send('chat:nova-mensagem'),
  mostrar: () => ipcRenderer.send('chat:mostrar'),
  chamadaRecebida: (nome) => ipcRenderer.send('chat:chamada', String(nome || '')),
  tentarDeNovo: () => ipcRenderer.send('chat:tentar-de-novo')
});
