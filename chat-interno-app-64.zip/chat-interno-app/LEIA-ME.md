# Chat Interno — app de computador

App de Windows que abre **só o Chat Interno** do portal CSSL Central TI, numa
janela própria, sem barra de endereço.

## Como funciona a atualização

- **O chat em si** vem do portal publicado no GitHub Pages
  (`tecnologiacssl/estoque-DG`), com `?app=chat` no endereço. Toda vez que o
  `index.html` for atualizado lá, o app já mostra a versão nova:
  - ao abrir o app;
  - ou sozinho, se ele ficou aberto perto do relógio (confere a cada 20 min e
    recarrega quando a janela estiver escondida, pra não atrapalhar ninguém).
- **A "casca" do app** (ícone, nome, janela) quase nunca muda. Quando mudar,
  ela se atualiza pelos *Releases* do repositório `tecnologiacssl/chat-interno-app`.

## Instalar

Rode `Chat-Interno-Setup-1.0.0.exe`. Ele instala sem pedir senha de
administrador, cria atalho na área de trabalho e no menu Iniciar e já abre.

O Windows pode mostrar "O Windows protegeu o computador" (o app não tem
assinatura digital paga). Clique em **Mais informações → Executar assim mesmo**.

## O que o app faz

- Abre direto no Chat Interno depois do login (o login fica salvo).
- O **X** só esconde a janela: o app continua perto do relógio recebendo
  mensagens e ligações. Para fechar de vez: botão direito no ícone → **Sair**.
- Avisa mensagem nova com notificação do Windows, pisca na barra de tarefas e
  mostra uma bolinha vermelha quando há mensagens não lidas.
- Ligação recebida traz a janela pra frente.
- Abre junto com o Windows (dá pra desligar no menu do ícone perto do relógio).
- Sem internet, mostra uma tela de "sem conexão" e tenta de novo sozinho.
- F5 recarrega; Ctrl + / Ctrl − mudam o tamanho da letra.

## Publicar uma versão nova da casca (só se mudar algo neste projeto)

1. Crie (uma vez) o repositório `tecnologiacssl/chat-interno-app` no GitHub e
   envie esta pasta para ele.
2. Aumente `"version"` no `package.json` (ex.: `1.0.1`) e faça commit.
3. Crie a tag `v1.0.1` e envie (`git tag v1.0.1 && git push --tags`).
4. O GitHub Actions gera o instalador e publica o Release. Os apps instalados
   baixam sozinhos e usam a versão nova na próxima vez que abrirem.

## Gerar o instalador no próprio computador (opcional)

Precisa do Node.js 20+ no Windows:

```
npm install
npm run build
```

O instalador sai em `dist/`.
